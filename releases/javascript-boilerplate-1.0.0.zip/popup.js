// function count() {
//     let noti_object = {
//         type: 'basic',
//         iconUrl: 'icon.png',
//         title: 'haha',
//         message: 'haha'
//     }
//     chrome.notifications.create('noti', noti_object)
//     chrome.notifications.onClicked.addListener(function(notificationId) {
//         chrome.tabs.create({url: 'https://www.google.com'});
//     }); 
// }
// document.getElementById('do-count').onclick = count;




console.log('works');

// chrome.runtime.onMessage.addListener(
//     function(request, sender, sendResponse) {
//         if (request.msg === "something_completed") {
//             //  To do something
//             console.log(request.data.subject)
//             console.log(request.data.content)
//         }
//     }
// );

// // chrome.runtime.sendMessage({"message": "msg"});

// let num = 0
// setInterval(() => {
//     document.getElementById('demo').textContent = num++
// }, 100)


// const INTERVAL = 100

// setTimeout(() => {
//     chrome.storage.sync.get(['toPopup'], function (data) {
//         if(data != null){
//             get_message(data)
//             chrome.storage.sync.set({'toPopup': null})
//         }
//     });
// }, INTERVAL)

// function send_message_to_background (data) {
//     chrome.storage.sync.set({ 'toBackground': data});
// }

// function get_message (data){
//     console.log(data)
// }

// send_message_to_background({sex: 'fun'})

// document.getElementById('do-count').addEventListener("click", () => {
//     // send_message_to_background({
//     //     title: 'SETTTING',
//     //     set: 'sex'
//     // })

//     chrome.runtime.sendMessage({
//         msg: "something_completed", 
//         data: {
//             subject: "Loading",
//             content: "Just completed!"
//         }
//     }); 
// });
